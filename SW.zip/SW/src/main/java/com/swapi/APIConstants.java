package com.swapi;

/**
 * API constants
 */
public class APIConstants {

    public static final String BASE_URL = "http://swapi.co/api/";
    public static final String APPLICATION_NAME = "SW";
}
